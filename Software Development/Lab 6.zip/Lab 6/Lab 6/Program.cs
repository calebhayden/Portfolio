﻿//B2732
//Lab 6
//Due 10/30/16
//CIS 199-75
//This lab uses nested loops to draw triangles in a console application.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6
{
    class stars
    {
        static void Main(string[] args)
        {
            //Constant used for comparison
            const int MAX_ROWS = 10;

            //Pattern A

            Console.WriteLine("Pattern A");
            Console.WriteLine();

            for (int row =1; row <= MAX_ROWS; row++)              //Outer loop, used to determine the number of rows the console writes
            {
                for (int star = 1; star <= row; star++)           //inner loop, used to determine the number of stars written in each line
                Console.Write("*");
                Console.WriteLine();
            }

            //Pattern B

            Console.WriteLine();
            Console.WriteLine("Pattern B");
            Console.WriteLine();

            for (int row = 1; row <= MAX_ROWS; row++)
            {
              for (int star = 10; star >= row; star--)
                    Console.Write("*");
                    Console.WriteLine();
            }
            
            //Pattern C
            
            Console.WriteLine();
            Console.WriteLine("Pattern C");
            Console.WriteLine();

            for (int row = 10; row >= 1; row--)
            {
              for (int space = 10 - row; space >=1; space--)        //Part of the inner loop, used to determine the number of blank spaces that appear before the stars in the line
                        Console.Write(" ");
              for (int star = 1; star <= row; star++)
                        Console.Write("*");
                  
                    Console.WriteLine();
            }

            //Pattern D

            Console.WriteLine();
            Console.WriteLine("Pattern D");
            Console.WriteLine();

            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int space = 10 - row; space >= 1; space--)
                    Console.Write(" ");
                for (int star = 1; star <= row; star++)
            Console.Write("*");

            Console.WriteLine();
            }
        }
        }
    }

