﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog1A
{
    public abstract class LibraryMediaItem : LibraryItem
    {
        double _duration; //the item's duration
        public enum MediaType { DVD, BLURAY, VHS, CD, SACD, VINYL };

        // Precondition: base class exists
        // Postcondition: a media item is initialized with values for title, publisher,
        //                copyright year, loan period, call number, and duration.
        public LibraryMediaItem(string theTitle, string thePublisher, int theCopyrightYear,
            int theLoanPeriod, string theCallNumber, double theDuration)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Duration = theDuration;
        }
        public double Duration
        {
            // Precondition: none
            // Postcondition: duration is returned
            get
            {
                return _duration;
            }
            
            // Precondition: none
            // Postcondition: duration is set to specified value
            set
            {
                if (value >= 0)
                    _duration = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                        $"{nameof(Duration)} must be >=0");
            }
        }
        //Determines the media type of the item
        public MediaType Medium;

        // Precondition: none
        // Postcondition: Calculates and returns the Late Fee. In this abstract class, 0 is returned.
        public override decimal CalcLateFee(int daysLate)
        {
            return 0.00M;
        }

        // Precondition: None
        // Postcondition: formats and returns string with item's info
        public override string ToString()
        {
            return base.ToString() + "\nDuration: " + Duration.ToString();
        }
    }
}
