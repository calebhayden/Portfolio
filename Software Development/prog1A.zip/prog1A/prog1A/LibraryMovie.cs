﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog1A
{



    public class LibraryMovie : LibraryMediaItem
    {
        public const decimal DVD_VHS_LATE_FEE = 1.00M;
        public const decimal BLURAY_LATE_FEE = 1.50M;
        public const decimal MAX_LATE_FEE = 25.00M;


        public enum MPAARatings { G, PG, PG13, R, NC17, U }
        public string _director;
        public MediaType _medium;
        public MPAARatings _rating;


        public LibraryMovie(string theTitle, string thePublisher, int theCopyrightYear,
            int theLoanPeriod, string theCallNumber, double theDuration, string theDirector,
            MediaType theMedium, MPAARatings theRating) 
            : base (theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theDuration)
        {

        }

        public string Director
        {
            // Precondition: none
            // Postcondition: director is returned
            get
            {
                return _director;
            }

            // Precondition: none
            // Postcondition: director is set to specified value
            set
            {
                _director = value;
            }
        }

        public MediaType Medium
        {

            // Precondition: none
            // Postcondition: medium is set to specified value
            get
            {
                return _medium;
            }

            // Precondition: none
            // Postcondition: medium set to specified value 

            set
            {
                if (value != MediaType.DVD || value != MediaType.BLURAY || value != MediaType.VHS)
                    throw new Exception("Media type is invalid.");
                else
                    _medium = value;              
            }       
        }

        public MPAARatings Rating
        {
            // Precondition: None
            // Postcondition: rating returned
            get
            {
                return _rating;
            }

            // Precondition: Type MPAARatings
            // Postcondition: rating set to specified value
            set
            {
                if (value != MPAARatings.G || value != MPAARatings.PG || value != MPAARatings.PG13 ||
                      value != MPAARatings.R || value != MPAARatings.NC17 || value != MPAARatings.U)
                    throw new Exception("Rating is invalid.");
                else
                    _rating = value;
            }


        }


        public override decimal CalcLateFee(int daysLate)
        {
          
        }


    }
}
