﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog1A
{
    public class LibraryBook : LibraryItem
    {
        private const decimal BOOK_LATE_FEE = .25M; //late fee charged per day
        private string _author; //The book's author

   
        // Precondition:  base class exists already
        // Postcondition: The library book has been initialized with the specified
        //                values for title, author, publisher, copyright year, and
        //                call number. The book is not checked out.
        public LibraryBook(string theTitle, string theAuthor, string thePublisher,
            int theCopyrightYear, int theLoanPeriod, string theCallNumber)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Author = theAuthor;  
        }

        public string Author
        {
            // Precondition:  None
            // Postcondition: The author has been returned
            get
            {
                return _author;
            }

            // Precondition:  None
            // Postcondition: The author has been set to the specified value
            set
            {
                // Since empty author is OK, just change null to empty string
                _author = (value == null ? string.Empty : value.Trim());
            }
        }
        // Precondition: none
        // Postcondition: Late fee is calculated
        public override decimal CalcLateFee(int daysLate)
        {
            return daysLate * BOOK_LATE_FEE;
        }

        // Precondition: None
        // Postcondition: string formatted and returned
        public override string ToString()
        {
            return base.ToString() + string.Format("\nAuthor: {0}", Author);
        }

    }
}
