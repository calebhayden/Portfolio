﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_4
{
    public partial class Form1 : Form
    {
        double totalAccepted = 0;
        double totalRejected = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void resultBtn_Click(object sender, EventArgs e)
        {


            double gpa;
            int testScore;
            const int testScoreThreshold1 = 60;
            const int testScoreThreshold2 = 80;
            const double gpaThreshold = 3.0;


            if (double.TryParse(gpaInputBox.Text, out gpa))
            if (int.TryParse(scoreInputBox.Text, out testScore))
                {
                    if ((gpa >= gpaThreshold && testScore >= testScoreThreshold1) || (gpa < gpaThreshold && testScore >= testScoreThreshold2))
                    {
                        resultOutputBox.Text = ("Accepted");
                        totalAccepted = totalAccepted + 1;
                        totalAcceptedOutputLabel.Text = totalAccepted.ToString();
                    }
                    else
                    {
                        resultOutputBox.Text = ("Rejected");
                        totalRejected = totalRejected + 1;
                        totalRejectedOutputLabel.Text = totalRejected.ToString();

                        
                    }
                }

            }
        }
    }


//            if (double.TryParse(gpaInputBox.Text, out gpa))
//            {
//                if (int.TryParse(scoreInputBox.Text, out testScore))
//                {
//                    if ((gpa >= gpaThreshold && testScore >= testScoreThreshold1) || (gpa < gpaThreshold && testScore >= testScoreThreshold2))
//                    {
//                        resultOutputBox.Text = ("Accepted");
//                        totalAccepted = totalAccepted + 1;
//                        totalAcceptedOutputLabel.Text = totalAccepted.ToString();
//                    }
//                    else
//                    {
//                        resultOutputBox.Text = ("Rejected");
//                        totalRejected = totalRejected + 1;
//                        totalRejectedOutputLabel.Text = totalRejected.ToString();
//                    }
//                    else
//            {
//                MessageBox.Show("Please enter a valid test score.");
//            }
//                }
//            }
            
        
//            else
//            {
//                MessageBox.Show("Please enter a Valid GPA");
//            }
//        }
//    }
//}
      










































