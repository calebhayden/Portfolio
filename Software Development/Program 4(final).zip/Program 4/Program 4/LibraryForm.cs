﻿//Grading ID: B2732
//CIS 199-75
//Program 4, due 12/6/16
//This program utilizes a form and a custom class in order to store user-defined library book data.



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class LibraryForm : Form
    {
        public LibraryForm()
        {
            InitializeComponent();
        }

        //creates a secondary list (invisible to user) that stores all properties of created Library Book objects
        List<LibraryBook> BookList = new List<LibraryBook>();
       
        //Add Book Event Handler
       private void addBookButton_Click(object sender, EventArgs e)
        {
            
            string Empty = "";//used in string validation
            bool inputEmpty =false;//used in string validation

            //All textboxes are checked that they are not empty and that input is valid.
            //If a textbox contains invalid data, an error message is displayed.
            //If a textbox matches the Empty variable, it is marked as empty by changing the inputEmpty variable to true.

            //when button is clicked, new LibraryBook object is created only when all data is valid.


            if (titleBox.Text != Empty)
            {  }
            else
            {
                MessageBox.Show("Please enter a valid Title.");
                    inputEmpty = true;
            }

            if (authorBox.Text != Empty)
            {  }
            else
            {
                MessageBox.Show("Please enter a valid Author.");
                inputEmpty = true;
            }

            if (publisherBox.Text != Empty)
            {  }
            else
            {
                MessageBox.Show("Please enter a valid Publisher.");
                inputEmpty = true;
            }
            int copyright;
            if (copyrightBox.Text != Empty && int.TryParse(copyrightBox.Text, out copyright))
            {  }
            else
            {
                MessageBox.Show("Please enter a valid Copyright Year.");
                inputEmpty = true;
            }
            if (callNumberBox.Text != Empty)
            {  }
            else
            {
                MessageBox.Show("Please enter a valid call number.");
                inputEmpty = true;
            }
            //Only if no textboxes are empty can a new object be created
            //If all textboxes contain a valid string, then the book object is added to the listBox and the secondary List
            //After object is created, the textboxes are cleared to allow new data entry

            if (!inputEmpty)
            {
                LibraryBook myBook = new LibraryBook(titleBox.Text, authorBox.Text, publisherBox.Text, int.Parse(copyrightBox.Text), callNumberBox.Text);
                BookList.Add(myBook);  
                bookListBox.Items.Add(titleBox.Text); //only the object's title is added to the listBox to avoid clutter
                titleBox.Text = "";
                authorBox.Text = "";
                publisherBox.Text = "";
                copyrightBox.Text = "";
                callNumberBox.Text = "";
            }

        }
        //Details button event handler
        private void detailsButton_Click(object sender, EventArgs e)
        {
            

            int index = bookListBox.SelectedIndex;//variable used to track position of object in list where user has clicked
            LibraryBook book;//object used to retrieve data for user selected book
            if (bookListBox.SelectedIndex != -1)//Verifies the user has selected a book
            {
                book = BookList[index];//retrieves book data from secondary list
                book.IsCheckedOut();//calls the IsCheckedOut method to determine book availability
                MessageBox.Show(book.ToString());//book details are displayed in a messagebox
            }
            else
                MessageBox.Show("Please select a book to view its details.");//If no book is selected, display an error message
        }

        //check out button event handler
        private void checkOutButton_Click(object sender, EventArgs e)
        {
            //data is retrieved and validated in the same way it is done for the details button event

            int index = bookListBox.SelectedIndex;

            if (bookListBox.SelectedIndex != -1)
            {
                LibraryBook book = BookList[index];
                book.IsCheckedOut();
                book.CheckOut();//CheckOut method is called, changing the check out status of the book to checked out
                MessageBox.Show("You have successfully checked out this book.");//confirmation message is displayed if sucessful
            }
            else
                MessageBox.Show("Please select a book to check out.");
        }
        //return button event handler
        private void returnButton_Click(object sender, EventArgs e)
        {
            //data is retrieved and validated in the same way it is done for the details button event
            int index = bookListBox.SelectedIndex;
           
            if (bookListBox.SelectedIndex != -1)
            {
                LibraryBook book = BookList[index];
                book.IsCheckedOut();
                book.ReturnToShelf();//ReturnToShelf method is called, changing the status of the book to available
                MessageBox.Show("You have successfully returned this book.");//confirmation message is displayed 
            }
            else
                MessageBox.Show("Please select a book to return.");//if no book is selected, error message is displayed
        }
    }
}
