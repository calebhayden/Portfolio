﻿namespace Program_4
{
    partial class LibraryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bookEntryGroupBox = new System.Windows.Forms.GroupBox();
            this.callNumberLbl = new System.Windows.Forms.Label();
            this.copyrightLbl = new System.Windows.Forms.Label();
            this.publisherLbl = new System.Windows.Forms.Label();
            this.authorLbl = new System.Windows.Forms.Label();
            this.titleLbl = new System.Windows.Forms.Label();
            this.addBookButton = new System.Windows.Forms.Button();
            this.callNumberBox = new System.Windows.Forms.TextBox();
            this.copyrightBox = new System.Windows.Forms.TextBox();
            this.publisherBox = new System.Windows.Forms.TextBox();
            this.authorBox = new System.Windows.Forms.TextBox();
            this.titleBox = new System.Windows.Forms.TextBox();
            this.bookDataGroupbox = new System.Windows.Forms.GroupBox();
            this.returnButton = new System.Windows.Forms.Button();
            this.checkOutButton = new System.Windows.Forms.Button();
            this.detailsButton = new System.Windows.Forms.Button();
            this.bookListBox = new System.Windows.Forms.ListBox();
            this.bookEntryGroupBox.SuspendLayout();
            this.bookDataGroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // bookEntryGroupBox
            // 
            this.bookEntryGroupBox.Controls.Add(this.callNumberLbl);
            this.bookEntryGroupBox.Controls.Add(this.copyrightLbl);
            this.bookEntryGroupBox.Controls.Add(this.publisherLbl);
            this.bookEntryGroupBox.Controls.Add(this.authorLbl);
            this.bookEntryGroupBox.Controls.Add(this.titleLbl);
            this.bookEntryGroupBox.Controls.Add(this.addBookButton);
            this.bookEntryGroupBox.Controls.Add(this.callNumberBox);
            this.bookEntryGroupBox.Controls.Add(this.copyrightBox);
            this.bookEntryGroupBox.Controls.Add(this.publisherBox);
            this.bookEntryGroupBox.Controls.Add(this.authorBox);
            this.bookEntryGroupBox.Controls.Add(this.titleBox);
            this.bookEntryGroupBox.Location = new System.Drawing.Point(12, 12);
            this.bookEntryGroupBox.Name = "bookEntryGroupBox";
            this.bookEntryGroupBox.Size = new System.Drawing.Size(215, 185);
            this.bookEntryGroupBox.TabIndex = 0;
            this.bookEntryGroupBox.TabStop = false;
            this.bookEntryGroupBox.Text = "Enter Library Book Data:";
            // 
            // callNumberLbl
            // 
            this.callNumberLbl.AutoSize = true;
            this.callNumberLbl.Location = new System.Drawing.Point(40, 129);
            this.callNumberLbl.Name = "callNumberLbl";
            this.callNumberLbl.Size = new System.Drawing.Size(67, 13);
            this.callNumberLbl.TabIndex = 1;
            this.callNumberLbl.Text = "Call Number:";
            // 
            // copyrightLbl
            // 
            this.copyrightLbl.AutoSize = true;
            this.copyrightLbl.Location = new System.Drawing.Point(28, 105);
            this.copyrightLbl.Name = "copyrightLbl";
            this.copyrightLbl.Size = new System.Drawing.Size(79, 13);
            this.copyrightLbl.TabIndex = 9;
            this.copyrightLbl.Text = "Copyright Year:";
            // 
            // publisherLbl
            // 
            this.publisherLbl.AutoSize = true;
            this.publisherLbl.Location = new System.Drawing.Point(54, 79);
            this.publisherLbl.Name = "publisherLbl";
            this.publisherLbl.Size = new System.Drawing.Size(53, 13);
            this.publisherLbl.TabIndex = 8;
            this.publisherLbl.Text = "Publisher:";
            // 
            // authorLbl
            // 
            this.authorLbl.AutoSize = true;
            this.authorLbl.Location = new System.Drawing.Point(66, 51);
            this.authorLbl.Name = "authorLbl";
            this.authorLbl.Size = new System.Drawing.Size(41, 13);
            this.authorLbl.TabIndex = 7;
            this.authorLbl.Text = "Author:";
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(77, 25);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(30, 13);
            this.titleLbl.TabIndex = 6;
            this.titleLbl.Text = "Title:";
            // 
            // addBookButton
            // 
            this.addBookButton.Location = new System.Drawing.Point(65, 156);
            this.addBookButton.Name = "addBookButton";
            this.addBookButton.Size = new System.Drawing.Size(75, 23);
            this.addBookButton.TabIndex = 5;
            this.addBookButton.Text = "Add Book";
            this.addBookButton.UseVisualStyleBackColor = true;
            this.addBookButton.Click += new System.EventHandler(this.addBookButton_Click);
            // 
            // callNumberBox
            // 
            this.callNumberBox.Location = new System.Drawing.Point(109, 126);
            this.callNumberBox.Name = "callNumberBox";
            this.callNumberBox.Size = new System.Drawing.Size(100, 20);
            this.callNumberBox.TabIndex = 4;
            // 
            // copyrightBox
            // 
            this.copyrightBox.Location = new System.Drawing.Point(109, 100);
            this.copyrightBox.Name = "copyrightBox";
            this.copyrightBox.Size = new System.Drawing.Size(100, 20);
            this.copyrightBox.TabIndex = 3;
            // 
            // publisherBox
            // 
            this.publisherBox.Location = new System.Drawing.Point(109, 74);
            this.publisherBox.Name = "publisherBox";
            this.publisherBox.Size = new System.Drawing.Size(100, 20);
            this.publisherBox.TabIndex = 2;
            // 
            // authorBox
            // 
            this.authorBox.Location = new System.Drawing.Point(109, 48);
            this.authorBox.Name = "authorBox";
            this.authorBox.Size = new System.Drawing.Size(100, 20);
            this.authorBox.TabIndex = 1;
            // 
            // titleBox
            // 
            this.titleBox.Location = new System.Drawing.Point(109, 22);
            this.titleBox.Name = "titleBox";
            this.titleBox.Size = new System.Drawing.Size(100, 20);
            this.titleBox.TabIndex = 0;
            // 
            // bookDataGroupbox
            // 
            this.bookDataGroupbox.Controls.Add(this.returnButton);
            this.bookDataGroupbox.Controls.Add(this.checkOutButton);
            this.bookDataGroupbox.Controls.Add(this.detailsButton);
            this.bookDataGroupbox.Controls.Add(this.bookListBox);
            this.bookDataGroupbox.Location = new System.Drawing.Point(245, 12);
            this.bookDataGroupbox.Name = "bookDataGroupbox";
            this.bookDataGroupbox.Size = new System.Drawing.Size(215, 185);
            this.bookDataGroupbox.TabIndex = 1;
            this.bookDataGroupbox.TabStop = false;
            this.bookDataGroupbox.Text = "Select a Book:";
            // 
            // returnButton
            // 
            this.returnButton.Location = new System.Drawing.Point(132, 123);
            this.returnButton.Name = "returnButton";
            this.returnButton.Size = new System.Drawing.Size(75, 23);
            this.returnButton.TabIndex = 5;
            this.returnButton.Text = "Return";
            this.returnButton.UseVisualStyleBackColor = true;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // checkOutButton
            // 
            this.checkOutButton.Location = new System.Drawing.Point(132, 97);
            this.checkOutButton.Name = "checkOutButton";
            this.checkOutButton.Size = new System.Drawing.Size(75, 23);
            this.checkOutButton.TabIndex = 4;
            this.checkOutButton.Text = "Check Out";
            this.checkOutButton.UseVisualStyleBackColor = true;
            this.checkOutButton.Click += new System.EventHandler(this.checkOutButton_Click);
            // 
            // detailsButton
            // 
            this.detailsButton.Location = new System.Drawing.Point(132, 71);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(75, 23);
            this.detailsButton.TabIndex = 3;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // bookListBox
            // 
            this.bookListBox.FormattingEnabled = true;
            this.bookListBox.Location = new System.Drawing.Point(6, 18);
            this.bookListBox.Name = "bookListBox";
            this.bookListBox.Size = new System.Drawing.Size(120, 134);
            this.bookListBox.TabIndex = 2;
            // 
            // LibraryForm
            // 
            this.AcceptButton = this.addBookButton;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(472, 216);
            this.Controls.Add(this.bookDataGroupbox);
            this.Controls.Add(this.bookEntryGroupBox);
            this.Name = "LibraryForm";
            this.Text = "Program 4";
            this.bookEntryGroupBox.ResumeLayout(false);
            this.bookEntryGroupBox.PerformLayout();
            this.bookDataGroupbox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox bookEntryGroupBox;
        private System.Windows.Forms.TextBox callNumberBox;
        private System.Windows.Forms.TextBox copyrightBox;
        private System.Windows.Forms.TextBox publisherBox;
        private System.Windows.Forms.TextBox authorBox;
        private System.Windows.Forms.TextBox titleBox;
        private System.Windows.Forms.Label callNumberLbl;
        private System.Windows.Forms.Label copyrightLbl;
        private System.Windows.Forms.Label publisherLbl;
        private System.Windows.Forms.Label authorLbl;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Button addBookButton;
        private System.Windows.Forms.GroupBox bookDataGroupbox;
        private System.Windows.Forms.Button returnButton;
        private System.Windows.Forms.Button checkOutButton;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.ListBox bookListBox;
    }
}

