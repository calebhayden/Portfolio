﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{

    // Library Book Class

    class LibraryBook
    {

        //Backing fields used to store the properties of the library book object

        private string _Title;             //stores the title
        private string _Author;            //stores the author
        private string _Publisher;         //stores the publisher
        private int _CopyrightYear = 2016; //stores the copyright year, default to 2016
        private string _CallNumber;        //stores the call number
        private bool _CheckedOut;          //stores the check out status of the book
        string BookStatus;                 //used to store text displaying the book's status
        bool isOut;                        //used in status validation

        //Constructor. Sets the default values of the library book. Text fields are empty, the default copyright year is 2016,
        //and by default, the book is not checked out. 
       
        //Precondition: The Add Book Button is pressed, creating a new Library Book object.
        //Postcondition: A new object is created, with its properties determined by user input. 
        public LibraryBook(string Title, string Author, string Publisher, int CopyrightYear, string CallNumber )
        {
            _Title = Title;
            _Author = Author;
            _Publisher = Publisher;
            _CopyrightYear = CopyrightYear;
            _CallNumber = CallNumber;
            _CheckedOut = false;

        }
        //title property
        public string Title
        {
            //Preconditon: user enters data in titleBox
            //Postcondition: the title property is assigned the user input

            get { return _Title; } //default value retrieved
            set { _Title = value; }//value is replaced by user input
        }
        //author property
        public string Author
        {
            //Precondtion: user enters data in authorBox
            //Postcondition: author property assigned user input

            get { return _Author; } //default value retrieved
            set { _Author = value; }//value is replaced by user input
        }
        //publisher property
        public string Publisher
        {
            //Precondition: user enters data in publisherBox
            //Postcondition: publisher property assigned user input

            get { return _Publisher; } //default value retrieved 
            set { _Publisher = value; }//value is replaced by user input
        }
        //copyright year property
        public int CopyrightYear
        {
            //precondition: user enters data in copyrightBox
            //Postcondition: copyright year property assigned user input if valid

            get { return _CopyrightYear; }//default value retrieved
            set { if (value >= 0) _CopyrightYear = value;//validation is performed, if value is positive, replace with user input
                else _CopyrightYear = 2016; }//else replace with default 2016
        }
        //call number property
        public string CallNumber
        {
            //Precondition: user enters data in callNumberBox
            //Postcondition: call number property assigned user input

            get { return _CallNumber; }//default value retrieved
            set { _CallNumber = value; }//value is replaced by user input
        }

        //Precondition: The check out button is clicked
        //Postcondition: the book's status is changed to reflect that it is checked out.
        public void CheckOut()
        {
            _CheckedOut = true;

        }

        //Precondition: The return button is clicked
        //Postcondition: status is changed to reflect that it has been returned.
        public void ReturnToShelf()
        {
            _CheckedOut = false;
        }
        
        //Precondition: Detail, check out, or return button is clicked
        //Postcondition: Book's status is verified
        public bool IsCheckedOut()
        {
           
            if (_CheckedOut == true)
                return isOut = true;
            else return isOut = false;
        }
        //Precondition: Details button is clicked
        //Postcondition: the book's details are displayed via messageBox.
        public override string ToString()
        {
            string bookInformation;//variable used to store all info regarding book
            

            if (IsCheckedOut() == true)     //validates the availability of selected book, adds info to the details
            {
                BookStatus = "Currently Checked Out";
            }
            else
                BookStatus = "Currently Available for Check Out";

            //All details are retrieved from the form, concatenated, formatted for display, 
            //and stored inside the bookInformation variable

        bookInformation = "Title: " + _Title.ToString() + Environment.NewLine
        + "Author: " + _Author.ToString() + Environment.NewLine
        + "Publisher: " + _Publisher.ToString() + Environment.NewLine
        + "Copyright Year: " + _CopyrightYear.ToString() + Environment.NewLine
        + "Call number: " + _CallNumber.ToString() + Environment.NewLine
        + "Book Status: " + BookStatus.ToString();
        return bookInformation;
        }
    }
}
