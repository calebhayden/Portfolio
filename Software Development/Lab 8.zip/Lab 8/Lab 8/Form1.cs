﻿//Grading ID B2732
//Due 11/13/16
//CIS 199-75
//This program uses range matching to display a ticket price based on a user input distance.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {

        //precondition: distanceInput is a valid integer
        //postcondition: The distance and price arrays are rangee matched and an appropriate 
        //ticket price is returned.


            int distanceInput;
            if (int.TryParse(distanceInputBox.Text, out distanceInput))//Input is parsed for validity
            {
                int[] distanceLowLimit = { 0, 100, 300, 500, };//Range used to match distance
                double[] price = { 25.00, 40.00, 55.00, 70.00, };//Range used to associate a price to given distance
                bool found = false; //variable used to assign boolean values when ranges are matched
                double customerPrice = 0; //Default value for the output variable.

                int index = distanceLowLimit.Length - 1; // Start from end
                                                         // since lower limits
                while (index >= 0 && !found)
                {
                    if (distanceInput >= distanceLowLimit[index])//Compares input to the ranges in the DistanceLowLimit array
                        found = true;
                    else
                        --index;
                }

                if (found)
                    customerPrice = price[index];//If ranges are matched, the price is assigned to the output variable and displayed on the form.

                priceOutputLabel.Text = customerPrice.ToString("c");
            }
            else
                MessageBox.Show("Enter a valid integer!");//If input is invalid, an error is displayed

        }
    }
}
