﻿namespace Lab_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthInputBox = new System.Windows.Forms.TextBox();
            this.languageGroupBox = new System.Windows.Forms.GroupBox();
            this.englishButton = new System.Windows.Forms.RadioButton();
            this.spanishButton = new System.Windows.Forms.RadioButton();
            this.italianButton = new System.Windows.Forms.RadioButton();
            this.outputLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.acceptButton = new System.Windows.Forms.Button();
            this.languageGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // monthInputBox
            // 
            this.monthInputBox.Location = new System.Drawing.Point(62, 25);
            this.monthInputBox.Name = "monthInputBox";
            this.monthInputBox.Size = new System.Drawing.Size(100, 20);
            this.monthInputBox.TabIndex = 0;
            // 
            // languageGroupBox
            // 
            this.languageGroupBox.Controls.Add(this.italianButton);
            this.languageGroupBox.Controls.Add(this.spanishButton);
            this.languageGroupBox.Controls.Add(this.englishButton);
            this.languageGroupBox.Location = new System.Drawing.Point(12, 51);
            this.languageGroupBox.Name = "languageGroupBox";
            this.languageGroupBox.Size = new System.Drawing.Size(150, 100);
            this.languageGroupBox.TabIndex = 1;
            this.languageGroupBox.TabStop = false;
            this.languageGroupBox.Text = "Choose Language:";
            // 
            // englishButton
            // 
            this.englishButton.AutoSize = true;
            this.englishButton.Checked = true;
            this.englishButton.Location = new System.Drawing.Point(6, 19);
            this.englishButton.Name = "englishButton";
            this.englishButton.Size = new System.Drawing.Size(59, 17);
            this.englishButton.TabIndex = 0;
            this.englishButton.TabStop = true;
            this.englishButton.Text = "English";
            this.englishButton.UseVisualStyleBackColor = true;
            // 
            // spanishButton
            // 
            this.spanishButton.AutoSize = true;
            this.spanishButton.Location = new System.Drawing.Point(6, 42);
            this.spanishButton.Name = "spanishButton";
            this.spanishButton.Size = new System.Drawing.Size(63, 17);
            this.spanishButton.TabIndex = 1;
            this.spanishButton.TabStop = true;
            this.spanishButton.Text = "Spanish";
            this.spanishButton.UseVisualStyleBackColor = true;
            // 
            // italianButton
            // 
            this.italianButton.AutoSize = true;
            this.italianButton.Location = new System.Drawing.Point(6, 65);
            this.italianButton.Name = "italianButton";
            this.italianButton.Size = new System.Drawing.Size(53, 17);
            this.italianButton.TabIndex = 2;
            this.italianButton.TabStop = true;
            this.italianButton.Text = "Italian";
            this.italianButton.UseVisualStyleBackColor = true;
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(12, 154);
            this.outputLabel.MinimumSize = new System.Drawing.Size(150, 20);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(150, 20);
            this.outputLabel.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Month #";
            // 
            // acceptButton
            // 
            this.acceptButton.Location = new System.Drawing.Point(50, 190);
            this.acceptButton.Name = "acceptButton";
            this.acceptButton.Size = new System.Drawing.Size(75, 23);
            this.acceptButton.TabIndex = 5;
            this.acceptButton.Text = "Look Up";
            this.acceptButton.UseVisualStyleBackColor = true;
            this.acceptButton.Click += new System.EventHandler(this.acceptButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.acceptButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(174, 225);
            this.Controls.Add(this.acceptButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.languageGroupBox);
            this.Controls.Add(this.monthInputBox);
            this.Name = "Form1";
            this.Text = "Lab 7";
            this.languageGroupBox.ResumeLayout(false);
            this.languageGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox monthInputBox;
        private System.Windows.Forms.GroupBox languageGroupBox;
        private System.Windows.Forms.RadioButton italianButton;
        private System.Windows.Forms.RadioButton spanishButton;
        private System.Windows.Forms.RadioButton englishButton;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button acceptButton;
    }
}

