﻿//B2732
//CIS 199-75
//Lab 7
//Due November 6, 2016
//This lab utilizes methods and string arrays to display the names of months in three different languages based
//on user input on a simple form.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int month;
        const int MIN_MONTH = 1;
        const int MAX_MONTH = 12;


        private void GetEnglishMonth()//Method called if the user selects the English radio button
        {
            //precondition: englishButton.Checked is TRUE
            //postcondition: matches user input to appropriate month and displays it in outPutLabel

            //user input is parsed and checked for validity. If invalid, displays an error
            int.TryParse(monthInputBox.Text, out month);
            if (month < MIN_MONTH || month > MAX_MONTH) 
                MessageBox.Show("Error!");
            
            //If parsed sucessfully, the remainder of the method executes
            else
            {
                //a string array of english month names is initialized
                string[] englishMonths = new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
                
                //1 is subtracted from the user input to avoid off-by-one error 
                //the coresponding month is pulled from the array and display in an output label on the form
                outputLabel.Text = englishMonths[month - 1]; 
                
            }
        }

        private void GetSpanishMonth()//Method called if the user selects the Spanish radio button
        {
            //precondition: spanishButton.Checked is TRUE
            //postcondition: matches user input to appropriate month and displays it in outPutLabel

            int.TryParse(monthInputBox.Text, out month);
            if (month < MIN_MONTH || month > MAX_MONTH)
                MessageBox.Show("Error!");
            else
            {
                string[] spanishMonths = new string[] { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" };
                outputLabel.Text = spanishMonths[month - 1];
            }
        }

        private void GetItalianMonth()//Method called if the user selects the Italian radio button
        {
            //precondition: italianButton.Checked is TRUE
            //postcondition: matches user input to appropriate month and displays it in outPutLabel

            int.TryParse(monthInputBox.Text, out month);
            if (month < MIN_MONTH || month > MAX_MONTH)
                MessageBox.Show("Error!");
            else
            {
                string[] italianMonths = new string[] { "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre" };
                outputLabel.Text = italianMonths[month - 1];
            }
        }

           private void acceptButton_Click(object sender, EventArgs e)
        {//Determines which radio button is checked and calls the corresponding method. 
            if (englishButton.Checked)
                {
                GetEnglishMonth();
                }
            else if (spanishButton.Checked)
            {
                GetSpanishMonth();
            }
            else
            {
                GetItalianMonth();
            }
        }
    }
}

    



