﻿//Grading ID: D3047
//Program 2
//CIS 200-01
//Due 3/9/17
//Adds a a modal dialog for checking out library items.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class CheckOutForm : Form
    {
        public CheckOutForm()
        {
            InitializeComponent();
        }
        //pre: none
        //post: Modal Dialog displays two combo boxes populated with a list of LibraryItems 
        //available for checkout, and LibraryPatrons respectively
        public CheckOutForm(List<LibraryItem> items, List<LibraryPatron> patrons)
        {
            InitializeComponent();
            foreach (LibraryItem item in items)
              if(item.IsCheckedOut() != true)//makes sure item isn't checked out
                checkOutItemComboBox.Items.Add(item.Title + ", " + item.CallNumber);//displays item title and callnumber in box
            foreach (LibraryPatron patron in patrons)
                checkOutPatronComboBox.Items.Add(patron.PatronName + ", " + patron.PatronID);//displays patron name and ID in box
        }
        //pre: OK button clicked
        //post: if selection valid, DialogResult.OK,else throw exception
        private void checkOutButton_Click(object sender, EventArgs e)
        {
            if(checkOutPatronComboBox != null && checkOutItemComboBox != null)
            {
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                throw new IndexOutOfRangeException("Please select an item and a patron.");
            }
        }
        //pre:cancel button clicked
        //post: DialogResult.Cancel, form is closed
        private void Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
