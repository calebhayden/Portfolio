﻿namespace LibraryItems
{
    partial class CheckOutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkOutItemComboBox = new System.Windows.Forms.ComboBox();
            this.checkOutPatronComboBox = new System.Windows.Forms.ComboBox();
            this.checkOutItemLabel = new System.Windows.Forms.Label();
            this.checkOutPatronLabel = new System.Windows.Forms.Label();
            this.checkOutButton = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkOutItemComboBox
            // 
            this.checkOutItemComboBox.FormattingEnabled = true;
            this.checkOutItemComboBox.Location = new System.Drawing.Point(105, 80);
            this.checkOutItemComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.checkOutItemComboBox.Name = "checkOutItemComboBox";
            this.checkOutItemComboBox.Size = new System.Drawing.Size(292, 24);
            this.checkOutItemComboBox.TabIndex = 0;
            // 
            // checkOutPatronComboBox
            // 
            this.checkOutPatronComboBox.FormattingEnabled = true;
            this.checkOutPatronComboBox.Location = new System.Drawing.Point(105, 124);
            this.checkOutPatronComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.checkOutPatronComboBox.Name = "checkOutPatronComboBox";
            this.checkOutPatronComboBox.Size = new System.Drawing.Size(292, 24);
            this.checkOutPatronComboBox.TabIndex = 1;
            // 
            // checkOutItemLabel
            // 
            this.checkOutItemLabel.AutoSize = true;
            this.checkOutItemLabel.Location = new System.Drawing.Point(57, 84);
            this.checkOutItemLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkOutItemLabel.Name = "checkOutItemLabel";
            this.checkOutItemLabel.Size = new System.Drawing.Size(38, 17);
            this.checkOutItemLabel.TabIndex = 2;
            this.checkOutItemLabel.Text = "Item:";
            // 
            // checkOutPatronLabel
            // 
            this.checkOutPatronLabel.AutoSize = true;
            this.checkOutPatronLabel.Location = new System.Drawing.Point(43, 128);
            this.checkOutPatronLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkOutPatronLabel.Name = "checkOutPatronLabel";
            this.checkOutPatronLabel.Size = new System.Drawing.Size(54, 17);
            this.checkOutPatronLabel.TabIndex = 3;
            this.checkOutPatronLabel.Text = "Patron:";
            // 
            // checkOutButton
            // 
            this.checkOutButton.Location = new System.Drawing.Point(105, 198);
            this.checkOutButton.Margin = new System.Windows.Forms.Padding(4);
            this.checkOutButton.Name = "checkOutButton";
            this.checkOutButton.Size = new System.Drawing.Size(100, 28);
            this.checkOutButton.TabIndex = 4;
            this.checkOutButton.Text = "Check Out";
            this.checkOutButton.UseVisualStyleBackColor = true;
            this.checkOutButton.Click += new System.EventHandler(this.checkOutButton_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(297, 198);
            this.Cancel.Margin = new System.Windows.Forms.Padding(4);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(100, 28);
            this.Cancel.TabIndex = 5;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // CheckOutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 271);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.checkOutButton);
            this.Controls.Add(this.checkOutPatronLabel);
            this.Controls.Add(this.checkOutItemLabel);
            this.Controls.Add(this.checkOutPatronComboBox);
            this.Controls.Add(this.checkOutItemComboBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CheckOutForm";
            this.Text = "Check Out Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label checkOutItemLabel;
        private System.Windows.Forms.Label checkOutPatronLabel;
        private System.Windows.Forms.Button checkOutButton;
        private System.Windows.Forms.Button Cancel;
        public System.Windows.Forms.ComboBox checkOutItemComboBox;
        public System.Windows.Forms.ComboBox checkOutPatronComboBox;
    }
}