﻿namespace LibraryItems
{
    partial class ReturnForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.returnComboBox = new System.Windows.Forms.ComboBox();
            this.returnItemLabel = new System.Windows.Forms.Label();
            this.returnItemButton = new System.Windows.Forms.Button();
            this.returnCancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // returnComboBox
            // 
            this.returnComboBox.FormattingEnabled = true;
            this.returnComboBox.Location = new System.Drawing.Point(105, 68);
            this.returnComboBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.returnComboBox.Name = "returnComboBox";
            this.returnComboBox.Size = new System.Drawing.Size(160, 24);
            this.returnComboBox.TabIndex = 0;
            // 
            // returnItemLabel
            // 
            this.returnItemLabel.AutoSize = true;
            this.returnItemLabel.Location = new System.Drawing.Point(57, 71);
            this.returnItemLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.returnItemLabel.Name = "returnItemLabel";
            this.returnItemLabel.Size = new System.Drawing.Size(38, 17);
            this.returnItemLabel.TabIndex = 1;
            this.returnItemLabel.Text = "Item:";
            // 
            // returnItemButton
            // 
            this.returnItemButton.Location = new System.Drawing.Point(61, 146);
            this.returnItemButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.returnItemButton.Name = "returnItemButton";
            this.returnItemButton.Size = new System.Drawing.Size(100, 28);
            this.returnItemButton.TabIndex = 2;
            this.returnItemButton.Text = "Return";
            this.returnItemButton.UseVisualStyleBackColor = true;
            this.returnItemButton.Click += new System.EventHandler(this.returnItemButton_Click);
            // 
            // returnCancelButton
            // 
            this.returnCancelButton.Location = new System.Drawing.Point(169, 146);
            this.returnCancelButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.returnCancelButton.Name = "returnCancelButton";
            this.returnCancelButton.Size = new System.Drawing.Size(100, 28);
            this.returnCancelButton.TabIndex = 3;
            this.returnCancelButton.Text = "Cancel";
            this.returnCancelButton.UseVisualStyleBackColor = true;
            this.returnCancelButton.Click += new System.EventHandler(this.returnCancelButton_Click);
            // 
            // ReturnForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 224);
            this.Controls.Add(this.returnCancelButton);
            this.Controls.Add(this.returnItemButton);
            this.Controls.Add(this.returnItemLabel);
            this.Controls.Add(this.returnComboBox);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ReturnForm";
            this.Text = "ReturnForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label returnItemLabel;
        private System.Windows.Forms.Button returnItemButton;
        private System.Windows.Forms.Button returnCancelButton;
        public System.Windows.Forms.ComboBox returnComboBox;
    }
}