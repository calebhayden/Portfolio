﻿//Grading ID: D3047
//Program 2
//CIS 200-01
//Due 3/9/17
//Adds a modal form for adding new patrons to the library.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class InsertPatronForm : Form
    {
        public InsertPatronForm()
        {
            InitializeComponent();
        }
        //pre: none
        //post: patronName is returned, set to value
        internal string myPatronName
        {
            get { return patronNameInputBox.Text; }
            set { patronNameInputBox.Text = value; }
        }
        //pre: none
        //post: patronID is returned, set to value
        internal string myPatronID
        {
            get { return patronIDInputBox.Text; }
            set { patronIDInputBox.Text = value; }
        }
        //pre: none
        //post: if NullorEmpty, focus change cancelled, error provider sets its message
        private void patronNameInputBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(patronNameInputBox.Text))
            {
                e.Cancel = true;
                nameErrorProvider.SetError(patronNameInputBox, "Please enter a value for name!");
            }
        }
        //pre: none
        //post: if NullorEmpty, focus change cancelled, error provider sets its message
        private void patronIDInputBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(patronIDInputBox.Text))
            {
                e.Cancel = true;
                idErrorProvider.SetError(patronIDInputBox, "Please enter a value for patron ID!");
            }
        }
        //pre: validation successful
        //post: error provider is cleared
        private void patronNameInputBox_Validated(object sender, EventArgs e)
        {
            nameErrorProvider.SetError(patronNameInputBox, "");
        }
        //pre: validation successful
        //post: error provider is cleared
        private void patronIDInputBox_Validated(object sender, EventArgs e)
        {
            idErrorProvider.SetError(patronIDInputBox, "");
        }
        //pre: Ok button clicked
        //post: children validated, DialogResult.OK
        private void patronOKButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            this.DialogResult = DialogResult.OK;
        }
        //pre: CancelButton MouseDown
        //post: if left click, DialogResult.Cancel
        private void patronCancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }
        //pre: CancelButton clicked
        //post: form closed
        private void patronCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
