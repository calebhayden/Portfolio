﻿//Grading ID: D3047
//Program 2
//CIS 200-01
//Due 3/9/17
//Adds a GUI to the library hierarchy.



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class Form1 : Form
    {

        //preloaded library test data
        internal Library Library = new Library(); //creates new library object
        LibraryBook book1 = new LibraryBook("Game of Thrones: A Plumber's Guide", "Plumbers' Crack", 2007, 5, "PO0P FX", "Joe Drainstop");
        LibraryBook book2 = new LibraryBook("History of Girl Scout Cookies", "Cookie Books", 2017, 7, "COOK IE", "Jane Girlscout");
        LibraryJournal journal1 = new LibraryJournal("A Comprehensive Assessment of InfoSec", "InfoSource",
            2016, 14, "DUMB C#", 13, 1, "I.T.", "Mac N. Tosh"); //1st test Periodical
        LibraryJournal journal2 = new LibraryJournal("Windows Vista- Why Bother?", "TechToday",
            2008, 1, "STUPI D1", 13, 2, "I.T.", "Carter Beauford"); //2st test Periodical
        LibraryMagazine magazine1 = new LibraryMagazine("Teen Cosmopolitan", "Bad Idea Press",
            2016, 5, "N0TPO RN", 17, 1); //1st test Magazine
        LibraryMagazine magazine2 = new LibraryMagazine("Teen Cosmopolitan", "Bad Idea Press",
            2016, 5, "N1TPO RN", 18, 2); //2nd test Magazine
        LibraryMagazine magazine3 = new LibraryMagazine("Minesweeper High Scores Weekly", "Do People Still Play This?",
            2014, 5, "MINES WP", 28, 36);
        LibraryMovie movie1 = new LibraryMovie("Silence of The Shawshank Redemption", "LigersGate", 1998, 7,
            "RIPOF F!", 176, "J.J. Spielberg", LibraryMediaItem.MediaType.VHS, LibraryMovie.MPAARatings.PG13); //1st test movie
        LibraryMovie movie2 = new LibraryMovie("Shaving Ryan's Privates", "XXX Spinoffs", 2006, 5, "GROSS EW", 69, "Ron Jeremy",
            LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.NC17);//2nd test movie
        LibraryMusic music1 = new LibraryMusic("Now That's What I Call Ska! 166", "Crap Music", 1997, 4, "BADTU NE", 75, "Drowsy Drew and the Dirty Dudes",
            LibraryMediaItem.MediaType.VINYL, 14);//1st test music
        LibraryMusic music2 = new LibraryMusic("The Best of: Men Without Hats", "Earblood Records", 1990, 4, "B4DTU N3", 68, "Men Without Hats",
            LibraryMediaItem.MediaType.CD, 1);//2nd test music


        LibraryPatron patron1 = new LibraryPatron("William Buttlicker", "1137"); // 1st test patron
        LibraryPatron patron2 = new LibraryPatron("Michael Clump", "6666"); // 2nd test patron
        LibraryPatron patron3 = new LibraryPatron("Dwight Schrute", "0001"); // 3rd test patron 
        LibraryPatron patron4 = new LibraryPatron("Jim Halpert", "2821"); // 4th test patron
        LibraryPatron patron5 = new LibraryPatron("Pam Beasely", "9138"); // 5th test patron

        public Form1()
        {
            InitializeComponent();
        }
        //precondition: application is opened
        //postcondition: main form is pre-loaded with a library filled with test data 
        private void Form1_Load(object sender, EventArgs e)
        {
            
            Library._items.Add(book1);
            Library._items.Add(book2);
            Library._items.Add(journal1);
            Library._items.Add(journal2);
            Library._items.Add(magazine1);
            Library._items.Add(magazine2);
            Library._items.Add(magazine3);
            Library._items.Add(movie1);
            Library._items.Add(movie2);
            Library._items.Add(music1);
            Library._items.Add(music2);

            Library._patrons.Add(patron1);
            Library._patrons.Add(patron2);
            Library._patrons.Add(patron3);
            Library._patrons.Add(patron4);
            Library._patrons.Add(patron5);
        }
        //precondition: "about" menu tab is clicked
        //postcondition: program info is displayed
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //messagebox to show program info
            MessageBox.Show("Grading ID: D3407\nProgram 2\nDue Date: 3/9\nCIS 200-01\nAdds a GUI to the library hierarchy.");
        }
        //pre: "exit" menu tab is clicked
        //post: application is terminated
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //closes the application
            this.Close();
        }
        //pre: insert patron menu tab is clicked
        //post: modal dialog is displayed, allowing user to input new patron data. Data is then added to the Library. 
        //Successful transaction is indicated by a messagebox.
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertPatronForm myPatronDialog = new InsertPatronForm();//creates new modal form
            string patronName;//holds patron's name
            string patronID;//holds patron's ID
            DialogResult result;//hold's the modal form

            result = myPatronDialog.ShowDialog();//form is displayed
  
            if (result == DialogResult.OK)//if OK is clicked
            {
                patronName = myPatronDialog.myPatronName;//patron name is collected
                 patronID = myPatronDialog.myPatronID;//patron ID is collected

                Library.AddPatron(patronName, patronID);//new patron object is collected
                MessageBox.Show("New patron added successfully.");//confirms successful completion
            }
        }
        //pre: insert book menu tab is clicked
        //post: modal dialog is displayed, allowing user to input new book data. Data is then added to the Library. 
        //Successful transaction is indicated by a messagebox.
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertBookForm myBookDialog = new InsertBookForm();//creates new modal form
            DialogResult result;//holds the modal form
            string bookName;//store the book title
            string bookAuthor;//store the book author
            string bookPublisher;//store the book publisher
            string bookCallNumber;//store the call number
            int bookLoanPeriod;//store the loan period
            int bookCopyrightYear;//store the copyright year
            result = myBookDialog.ShowDialog();//form is displayed
            if (result == DialogResult.OK)//if OK is clicked
            {
                bookName = myBookDialog.myBookTitle;//collect name
                bookAuthor = myBookDialog.myBookAuthor;//collect author
                bookPublisher = myBookDialog.myBookPublisher;//collect publisher
                bookCallNumber = myBookDialog.myBookCallNumber;//collect callnumber
                bookLoanPeriod = int.Parse(myBookDialog.myBookLoanPeriod);//parse loan period and collect 
                bookCopyrightYear = int.Parse(myBookDialog.myBookCopyrightYear);//parse copyright year and collect

                Library.AddLibraryBook(bookName, bookPublisher, bookCopyrightYear, bookLoanPeriod, bookCallNumber, bookAuthor);//create new LibraryBook object
                MessageBox.Show("Book has been added successfully.");//confirms successful completion
            }

        }
        //pre:check out menu tab is clicked
        //post: modal dialog is displayed, allowing user to select an item to check out. Item status is changed to "checked out" and item is
        //no longer considered to be stored inside the library until it is returned. Successful transaction is indicated by a messagebox.
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Library._items.Count() == 0)//makes sure library is not empty 
                MessageBox.Show("There are currently no items in the library.");
            else
            {
                //if library is not empty, grab items and patrons from Library object
                CheckOutForm myCheckoutDialog = new CheckOutForm(Library.GetItemsList(), Library.GetPatronsList());
                myCheckoutDialog.ShowDialog();//form is displayed

                if (myCheckoutDialog.DialogResult == DialogResult.OK)//if OK is clicked
                {
                    int itemsIndex = myCheckoutDialog.checkOutItemComboBox.SelectedIndex;//matches selected item to location in Library
                    int patronIndex = myCheckoutDialog.checkOutPatronComboBox.SelectedIndex;//matches selected patron to location in LibraryPatron

                    Library._items[itemsIndex].CheckOut(Library._patrons[patronIndex]);//checks out the item and grabs its associated patron
                    MessageBox.Show("Item has been checked out.");//confirms successful completion

                }
            }
        }
        //pre:return item menu tab is clicked
        //post: modal dialog is displayed, allowing user to select item to return. Item status is then changed to "not checked out" and is 
        //returned to the library for another checkout. Successful transaction is indicated by a messagebox.
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Library.GetCheckedOutCount() == 0)//makes sure there is at least one checked out item 
                MessageBox.Show("There are no items checked out.");
            else
            {
                //if checked out list isnt empty, grab checked out items
                ReturnForm myReturnDialog = new ReturnForm(Library.GetItemsList());
                myReturnDialog.ShowDialog();//form is displayed

                if (myReturnDialog.DialogResult == DialogResult.OK)//if OK is clicked
                {
                    string selectedItem = myReturnDialog.returnComboBox.SelectedItem.ToString();//grabs item selected in comboBox
                    string callNumber = selectedItem.Split(',')[1].Trim();//splits the string and returns select item's callnumber


                    // foreach item in Library._items, check selectedReturnItem call number against
                    // item.CallNumber ... if ==, call item.returnToShelf()
                    //I think this satisfies extra credit requirements?
                    foreach (LibraryItem item in Library.GetItemsList())
                    {
                        if (item.CallNumber == callNumber)
                        {
                            item.ReturnToShelf();
                            MessageBox.Show("Item has been returned.");
                        }
                    }
                }
            }
        }
        //pre: patron report menu tab is clicked
        //post: LibraryPatron data is displayed on the main form
        private void patronsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string patronResult = null;//stores patron data
            List<LibraryPatron> list = Library.GetPatronsList();//creates list of library patrons
            foreach (LibraryPatron patron in list)//use a foreach loop to step through each patron, writing formatted data to main form
            {
                patronResult += patron + System.Environment.NewLine + "=----------=" + System.Environment.NewLine;
            }
            outputTextbox.Text = "List of Library Patrons:" + System.Environment.NewLine + "=----------=" + System.Environment.NewLine + patronResult;
        }
        //pre: item report menu tab is clicked
        //post: LibraryItem data is displayed on the main form
        private void itemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string itemResult = null;//stores LibraryItem data
            List<LibraryItem> list = Library.GetItemsList();//creates list of library items
            foreach (LibraryItem patron in list)//use a loop to step through each item, writting formatted data to main form
            {
                itemResult += patron + System.Environment.NewLine + "=----------=" + System.Environment.NewLine;
            }
            outputTextbox.Text = "List of Library Items:" + System.Environment.NewLine + "=----------=" + System.Environment.NewLine + itemResult;
        }
        //pre: check out items report menu tab is clicked
        //post: checked out items data is displayed on the main form
        private void checkedOutItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string itemResult = null;//store item data
            List<LibraryItem> list = Library.GetItemsList();//creates a list of items
            foreach (LibraryItem item in list)//use a loop to step through item, check that item.IsCheckedOut(), if true, display to main form 
            {
                if (item.IsCheckedOut())
                {
                    itemResult += item + System.Environment.NewLine + "=----------=" + System.Environment.NewLine;
                }
            }

            outputTextbox.Text = "List of Checked Out Items: " + System.Environment.NewLine + "=----------=" + System.Environment.NewLine + itemResult
                + System.Environment.NewLine + "Number of items checked out: " + Library.GetCheckedOutCount().ToString();
        }
    }
}