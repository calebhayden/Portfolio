﻿namespace LibraryItems
{
    partial class InsertBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bookTitleBox = new System.Windows.Forms.TextBox();
            this.bookAuthorBox = new System.Windows.Forms.TextBox();
            this.bookPublisherBox = new System.Windows.Forms.TextBox();
            this.bookTitleLabel = new System.Windows.Forms.Label();
            this.bookAuthorLabel = new System.Windows.Forms.Label();
            this.bookPublisherLabel = new System.Windows.Forms.Label();
            this.bookCopyrightBox = new System.Windows.Forms.TextBox();
            this.bookCallNumberBox = new System.Windows.Forms.TextBox();
            this.bookLoanPeriodBox = new System.Windows.Forms.TextBox();
            this.bookCopyrightLabel = new System.Windows.Forms.Label();
            this.bookCallNumberLabel = new System.Windows.Forms.Label();
            this.bookLoanPeriodLabel = new System.Windows.Forms.Label();
            this.bookOKButton = new System.Windows.Forms.Button();
            this.bookCancelButton = new System.Windows.Forms.Button();
            this.titleErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.authorErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.publisherErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.copyrightErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.callErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.loanErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.titleErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.authorErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisherErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.copyrightErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.callErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // bookTitleBox
            // 
            this.bookTitleBox.Location = new System.Drawing.Point(95, 62);
            this.bookTitleBox.Margin = new System.Windows.Forms.Padding(4);
            this.bookTitleBox.Name = "bookTitleBox";
            this.bookTitleBox.Size = new System.Drawing.Size(132, 22);
            this.bookTitleBox.TabIndex = 0;
            this.bookTitleBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookTitleBox_Validating);
            this.bookTitleBox.Validated += new System.EventHandler(this.bookTitleBox_Validated);
            // 
            // bookAuthorBox
            // 
            this.bookAuthorBox.Location = new System.Drawing.Point(95, 105);
            this.bookAuthorBox.Margin = new System.Windows.Forms.Padding(4);
            this.bookAuthorBox.Name = "bookAuthorBox";
            this.bookAuthorBox.Size = new System.Drawing.Size(132, 22);
            this.bookAuthorBox.TabIndex = 1;
            this.bookAuthorBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookAuthorBox_Validating);
            this.bookAuthorBox.Validated += new System.EventHandler(this.bookAuthorBox_Validated);
            // 
            // bookPublisherBox
            // 
            this.bookPublisherBox.Location = new System.Drawing.Point(95, 153);
            this.bookPublisherBox.Margin = new System.Windows.Forms.Padding(4);
            this.bookPublisherBox.Name = "bookPublisherBox";
            this.bookPublisherBox.Size = new System.Drawing.Size(132, 22);
            this.bookPublisherBox.TabIndex = 2;
            this.bookPublisherBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookPublisherBox_Validating);
            this.bookPublisherBox.Validated += new System.EventHandler(this.bookPublisherBox_Validated);
            // 
            // bookTitleLabel
            // 
            this.bookTitleLabel.AutoSize = true;
            this.bookTitleLabel.Location = new System.Drawing.Point(45, 65);
            this.bookTitleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookTitleLabel.Name = "bookTitleLabel";
            this.bookTitleLabel.Size = new System.Drawing.Size(39, 17);
            this.bookTitleLabel.TabIndex = 3;
            this.bookTitleLabel.Text = "Title:";
            // 
            // bookAuthorLabel
            // 
            this.bookAuthorLabel.AutoSize = true;
            this.bookAuthorLabel.Location = new System.Drawing.Point(31, 108);
            this.bookAuthorLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookAuthorLabel.Name = "bookAuthorLabel";
            this.bookAuthorLabel.Size = new System.Drawing.Size(54, 17);
            this.bookAuthorLabel.TabIndex = 4;
            this.bookAuthorLabel.Text = "Author:";
            // 
            // bookPublisherLabel
            // 
            this.bookPublisherLabel.AutoSize = true;
            this.bookPublisherLabel.Location = new System.Drawing.Point(16, 156);
            this.bookPublisherLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookPublisherLabel.Name = "bookPublisherLabel";
            this.bookPublisherLabel.Size = new System.Drawing.Size(71, 17);
            this.bookPublisherLabel.TabIndex = 5;
            this.bookPublisherLabel.Text = "Publisher:";
            // 
            // bookCopyrightBox
            // 
            this.bookCopyrightBox.Location = new System.Drawing.Point(392, 62);
            this.bookCopyrightBox.Margin = new System.Windows.Forms.Padding(4);
            this.bookCopyrightBox.Name = "bookCopyrightBox";
            this.bookCopyrightBox.Size = new System.Drawing.Size(93, 22);
            this.bookCopyrightBox.TabIndex = 6;
            this.bookCopyrightBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookCopyrightBox_Validating);
            this.bookCopyrightBox.Validated += new System.EventHandler(this.bookCopyrightBox_Validated);
            // 
            // bookCallNumberBox
            // 
            this.bookCallNumberBox.Location = new System.Drawing.Point(392, 105);
            this.bookCallNumberBox.Margin = new System.Windows.Forms.Padding(4);
            this.bookCallNumberBox.Name = "bookCallNumberBox";
            this.bookCallNumberBox.Size = new System.Drawing.Size(93, 22);
            this.bookCallNumberBox.TabIndex = 7;
            this.bookCallNumberBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookCallNumberBox_Validating);
            this.bookCallNumberBox.Validated += new System.EventHandler(this.bookCallNumberBox_Validated);
            // 
            // bookLoanPeriodBox
            // 
            this.bookLoanPeriodBox.Location = new System.Drawing.Point(392, 153);
            this.bookLoanPeriodBox.Margin = new System.Windows.Forms.Padding(4);
            this.bookLoanPeriodBox.Name = "bookLoanPeriodBox";
            this.bookLoanPeriodBox.Size = new System.Drawing.Size(93, 22);
            this.bookLoanPeriodBox.TabIndex = 8;
            this.bookLoanPeriodBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookLoanPeriodBox_Validating);
            this.bookLoanPeriodBox.Validated += new System.EventHandler(this.bookLoanPeriodBox_Validated);
            // 
            // bookCopyrightLabel
            // 
            this.bookCopyrightLabel.AutoSize = true;
            this.bookCopyrightLabel.Location = new System.Drawing.Point(279, 65);
            this.bookCopyrightLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookCopyrightLabel.Name = "bookCopyrightLabel";
            this.bookCopyrightLabel.Size = new System.Drawing.Size(106, 17);
            this.bookCopyrightLabel.TabIndex = 9;
            this.bookCopyrightLabel.Text = "Copyright Year:";
            // 
            // bookCallNumberLabel
            // 
            this.bookCallNumberLabel.AutoSize = true;
            this.bookCallNumberLabel.Location = new System.Drawing.Point(295, 108);
            this.bookCallNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookCallNumberLabel.Name = "bookCallNumberLabel";
            this.bookCallNumberLabel.Size = new System.Drawing.Size(89, 17);
            this.bookCallNumberLabel.TabIndex = 10;
            this.bookCallNumberLabel.Text = "Call Number:";
            // 
            // bookLoanPeriodLabel
            // 
            this.bookLoanPeriodLabel.AutoSize = true;
            this.bookLoanPeriodLabel.Location = new System.Drawing.Point(295, 156);
            this.bookLoanPeriodLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookLoanPeriodLabel.Name = "bookLoanPeriodLabel";
            this.bookLoanPeriodLabel.Size = new System.Drawing.Size(89, 17);
            this.bookLoanPeriodLabel.TabIndex = 11;
            this.bookLoanPeriodLabel.Text = "Loan Period:";
            // 
            // bookOKButton
            // 
            this.bookOKButton.Location = new System.Drawing.Point(128, 228);
            this.bookOKButton.Margin = new System.Windows.Forms.Padding(4);
            this.bookOKButton.Name = "bookOKButton";
            this.bookOKButton.Size = new System.Drawing.Size(100, 28);
            this.bookOKButton.TabIndex = 12;
            this.bookOKButton.Text = "OK";
            this.bookOKButton.UseVisualStyleBackColor = true;
            this.bookOKButton.Click += new System.EventHandler(this.bookOKButton_Click);
            // 
            // bookCancelButton
            // 
            this.bookCancelButton.Location = new System.Drawing.Point(283, 228);
            this.bookCancelButton.Margin = new System.Windows.Forms.Padding(4);
            this.bookCancelButton.Name = "bookCancelButton";
            this.bookCancelButton.Size = new System.Drawing.Size(100, 28);
            this.bookCancelButton.TabIndex = 13;
            this.bookCancelButton.Text = "Cancel";
            this.bookCancelButton.UseVisualStyleBackColor = true;
            this.bookCancelButton.Click += new System.EventHandler(this.bookCancelButton_Click);
            this.bookCancelButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bookCancelButton_MouseDown);
            // 
            // titleErrorProvider
            // 
            this.titleErrorProvider.ContainerControl = this;
            // 
            // authorErrorProvider
            // 
            this.authorErrorProvider.ContainerControl = this;
            // 
            // publisherErrorProvider
            // 
            this.publisherErrorProvider.ContainerControl = this;
            // 
            // copyrightErrorProvider
            // 
            this.copyrightErrorProvider.ContainerControl = this;
            // 
            // callErrorProvider
            // 
            this.callErrorProvider.ContainerControl = this;
            // 
            // loanErrorProvider
            // 
            this.loanErrorProvider.ContainerControl = this;
            // 
            // InsertBookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 271);
            this.Controls.Add(this.bookCancelButton);
            this.Controls.Add(this.bookOKButton);
            this.Controls.Add(this.bookLoanPeriodLabel);
            this.Controls.Add(this.bookCallNumberLabel);
            this.Controls.Add(this.bookCopyrightLabel);
            this.Controls.Add(this.bookLoanPeriodBox);
            this.Controls.Add(this.bookCallNumberBox);
            this.Controls.Add(this.bookCopyrightBox);
            this.Controls.Add(this.bookPublisherLabel);
            this.Controls.Add(this.bookAuthorLabel);
            this.Controls.Add(this.bookTitleLabel);
            this.Controls.Add(this.bookPublisherBox);
            this.Controls.Add(this.bookAuthorBox);
            this.Controls.Add(this.bookTitleBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "InsertBookForm";
            this.Text = "Add New Book";
            ((System.ComponentModel.ISupportInitialize)(this.titleErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.authorErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisherErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.copyrightErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.callErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label bookTitleLabel;
        private System.Windows.Forms.Label bookAuthorLabel;
        private System.Windows.Forms.Label bookPublisherLabel;
        private System.Windows.Forms.Label bookCopyrightLabel;
        private System.Windows.Forms.Label bookCallNumberLabel;
        private System.Windows.Forms.Label bookLoanPeriodLabel;
        private System.Windows.Forms.Button bookOKButton;
        private System.Windows.Forms.Button bookCancelButton;
        private System.Windows.Forms.ErrorProvider titleErrorProvider;
        private System.Windows.Forms.ErrorProvider authorErrorProvider;
        private System.Windows.Forms.ErrorProvider publisherErrorProvider;
        private System.Windows.Forms.ErrorProvider copyrightErrorProvider;
        private System.Windows.Forms.ErrorProvider callErrorProvider;
        private System.Windows.Forms.ErrorProvider loanErrorProvider;
        public System.Windows.Forms.TextBox bookTitleBox;
        public System.Windows.Forms.TextBox bookAuthorBox;
        public System.Windows.Forms.TextBox bookPublisherBox;
        public System.Windows.Forms.TextBox bookCopyrightBox;
        public System.Windows.Forms.TextBox bookCallNumberBox;
        public System.Windows.Forms.TextBox bookLoanPeriodBox;
    }
}