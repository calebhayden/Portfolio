﻿//Grading ID: D3047
//Program 2
//CIS 200-01
//Due 3/9/17
//Adds a modal form for returning checked out items to the library.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace LibraryItems
{
    public partial class ReturnForm : Form
    {
        public ReturnForm()
        {
            InitializeComponent();
        }
        //pre: none
        //post: Modal Dialog displays two combo boxes populated with a list of LibraryItems 
        //previously checked out, and LibraryPatrons respectively
        public ReturnForm(List<LibraryItem> items)
        {
            //use a loop to step through libraryItems, grab if IsCheckedOut(), display title and callNumber
            InitializeComponent();
            foreach (LibraryItem item in items)
                if (item.IsCheckedOut())
                    returnComboBox.Items.Add(item.Title + ", " + item.CallNumber);
        }
        //pre: ok button clicked
        //post: if selection != null, DialogResult.OK
        private void returnItemButton_Click(object sender, EventArgs e)
        {
            if (returnComboBox != null)
                this.DialogResult = DialogResult.OK;
        }
        //pre: cancel button clicked
        //post: DialogResult.Cancel
        private void returnCancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
