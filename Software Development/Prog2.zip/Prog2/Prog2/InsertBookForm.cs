﻿//Grading ID: D3047
//Program 2
//CIS 200-01
//Due 3/9/17
//Adds a modal form for adding new books to the library.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class InsertBookForm : Form
    {
        public InsertBookForm()
        {
            InitializeComponent();
        }
        //pre: none
        //post: bookTitle is returned, set to value
        internal string myBookTitle
        {
            get { return bookTitleBox.Text; }
            set { bookTitleBox.Text = value; }
        }
        //pre: none
        //post: bookAuthor is returned, set to value
        internal string myBookAuthor
        {
            get { return bookAuthorBox.Text; }
            set { bookAuthorBox.Text = value; }
        }
        //pre: none
        //post: bookPublisher is returned, set to value
        internal string myBookPublisher
        {
            get { return bookPublisherBox.Text; }
            set { bookPublisherBox.Text = value; }
        }
        //pre: none
        //post: bookCallNumber is returned, set to value
        internal string myBookCallNumber
        {
            get { return bookCallNumberBox.Text; }
            set { bookCallNumberBox.Text = value; }

        }
        //pre: none
        //post: bookLoanPeriod is returned, set to value
        internal string myBookLoanPeriod
        {
            get { return bookLoanPeriodBox.Text; }
            set { bookLoanPeriodBox.Text = value; }
        }
        //pre: none
        //post: bookCopyrightYear is returned, set to value
        internal string myBookCopyrightYear
        {
            get { return bookCopyrightBox.Text; }
            set { bookCopyrightBox.Text = value; }
        }
        //pre: none
        //post: if NullorEmpty, focus change cancelled, error provider sets its message
        private void bookTitleBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(bookTitleBox.Text))
            {
                e.Cancel = true;
                titleErrorProvider.SetError(bookTitleBox, "Enter a value for title!");
            }
        }

        //pre: none
        //post: if NullorEmpty, focus change cancelled, error provider sets its message
        private void bookAuthorBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(bookAuthorBox.Text))
            {
                e.Cancel = true;
                authorErrorProvider.SetError(bookAuthorBox, "Enter a value for author!");
            }
        }

        //pre: none
        //post: if NullorEmpty, focus change cancelled, error provider sets its message
        private void bookPublisherBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(bookPublisherBox.Text))
            {
                e.Cancel = true;
                publisherErrorProvider.SetError(bookPublisherBox, "Enter a value for publisher!");
            }
        }

        //pre: none
        //post: if NullorEmpty, focus change cancelled, error provider sets its message
        private void bookCallNumberBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(bookCallNumberBox.Text))
            {
                e.Cancel = true;
                callErrorProvider.SetError(bookCallNumberBox, "Enter a value for call number!");
            }
        }

        //pre: none
        //post: if int cant be parsed, or int is <0, focus change cancelled, error provider sets its message
        private void bookCopyrightBox_Validating(object sender, CancelEventArgs e)
        {
            int number;
            if (!int.TryParse(bookCopyrightBox.Text, out number))
            {
                e.Cancel = true;
                copyrightErrorProvider.SetError(bookCopyrightBox, "Enter a valid value for copyright year!");
            }
            else if (number < 0)
                copyrightErrorProvider.SetError(bookCopyrightBox, "Enter a non-negative integer!");
        }

        //pre: none
        //post: if int cant be parsed, or int is < 0 focus change cancelled, error provider sets its message
        private void bookLoanPeriodBox_Validating(object sender, CancelEventArgs e)
        {
            int number;
            if (!int.TryParse(bookLoanPeriodBox.Text, out number))
            {
                e.Cancel = true;
                loanErrorProvider.SetError(bookLoanPeriodBox, "Enter a valid value for loan period!");
            }
            else if (number < 0)
                loanErrorProvider.SetError(bookLoanPeriodBox, "Enter a non-negative integer!");
        }

        //pre: validation successful
        //post: error provider is cleared
        private void bookTitleBox_Validated(object sender, EventArgs e)
        {
            titleErrorProvider.SetError(bookTitleBox, "");
        }

        //pre: validation successful
        //post: error provider is cleared
        private void bookAuthorBox_Validated(object sender, EventArgs e)
        {
            authorErrorProvider.SetError(bookAuthorBox, "");
        }

        //pre: validation successful
        //post: error provider is cleared
        private void bookPublisherBox_Validated(object sender, EventArgs e)
        {
            publisherErrorProvider.SetError(bookPublisherBox, "");
        }

        //pre: validation successful
        //post: error provider is cleared
        private void bookCopyrightBox_Validated(object sender, EventArgs e)
        {
            copyrightErrorProvider.SetError(bookCopyrightBox, "");
        }

        //pre: validation successful
        //post: error provider is cleared
        private void bookLoanPeriodBox_Validated(object sender, EventArgs e)
        {
            loanErrorProvider.SetError(bookLoanPeriodBox, "");
        }

        //pre: validation successful
        //post: error provider is cleared
        private void bookCallNumberBox_Validated(object sender, EventArgs e)
        {
            callErrorProvider.SetError(bookCallNumberBox, "");
        }

      //pre: Ok clicked
      //post: children validated, sets DialogResult.OK
        private void bookOKButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
        //pre: bookCancelButton MouseDown
        //post: If a left click, sets DialogResult.Cancel
        private void bookCancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }
        //pre: bookCancelButton clicked
        //post: form closed
        private void bookCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
