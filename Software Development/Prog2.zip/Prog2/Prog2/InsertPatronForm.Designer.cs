﻿namespace LibraryItems
{
    partial class InsertPatronForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.patronNameInputBox = new System.Windows.Forms.TextBox();
            this.patronIDInputBox = new System.Windows.Forms.TextBox();
            this.patronNameLabel = new System.Windows.Forms.Label();
            this.patronIdLabel = new System.Windows.Forms.Label();
            this.patronOkButton = new System.Windows.Forms.Button();
            this.patronCancelButton = new System.Windows.Forms.Button();
            this.nameErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.idErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nameErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.idErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // patronNameInputBox
            // 
            this.patronNameInputBox.Location = new System.Drawing.Point(95, 55);
            this.patronNameInputBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.patronNameInputBox.Name = "patronNameInputBox";
            this.patronNameInputBox.Size = new System.Drawing.Size(189, 22);
            this.patronNameInputBox.TabIndex = 0;
            this.patronNameInputBox.Validating += new System.ComponentModel.CancelEventHandler(this.patronNameInputBox_Validating);
            this.patronNameInputBox.Validated += new System.EventHandler(this.patronNameInputBox_Validated);
            // 
            // patronIDInputBox
            // 
            this.patronIDInputBox.Location = new System.Drawing.Point(95, 95);
            this.patronIDInputBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.patronIDInputBox.Name = "patronIDInputBox";
            this.patronIDInputBox.Size = new System.Drawing.Size(189, 22);
            this.patronIDInputBox.TabIndex = 1;
            this.patronIDInputBox.Validating += new System.ComponentModel.CancelEventHandler(this.patronIDInputBox_Validating);
            this.patronIDInputBox.Validated += new System.EventHandler(this.patronIDInputBox_Validated);
            // 
            // patronNameLabel
            // 
            this.patronNameLabel.AutoSize = true;
            this.patronNameLabel.Location = new System.Drawing.Point(36, 59);
            this.patronNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.patronNameLabel.Name = "patronNameLabel";
            this.patronNameLabel.Size = new System.Drawing.Size(49, 17);
            this.patronNameLabel.TabIndex = 2;
            this.patronNameLabel.Text = "Name:";
            // 
            // patronIdLabel
            // 
            this.patronIdLabel.AutoSize = true;
            this.patronIdLabel.Location = new System.Drawing.Point(5, 98);
            this.patronIdLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.patronIdLabel.Name = "patronIdLabel";
            this.patronIdLabel.Size = new System.Drawing.Size(79, 17);
            this.patronIdLabel.TabIndex = 3;
            this.patronIdLabel.Text = "ID Number:";
            // 
            // patronOkButton
            // 
            this.patronOkButton.Location = new System.Drawing.Point(63, 187);
            this.patronOkButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.patronOkButton.Name = "patronOkButton";
            this.patronOkButton.Size = new System.Drawing.Size(100, 28);
            this.patronOkButton.TabIndex = 4;
            this.patronOkButton.Text = "OK";
            this.patronOkButton.UseVisualStyleBackColor = true;
            this.patronOkButton.Click += new System.EventHandler(this.patronOKButton_Click);
            // 
            // patronCancelButton
            // 
            this.patronCancelButton.Location = new System.Drawing.Point(185, 187);
            this.patronCancelButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.patronCancelButton.Name = "patronCancelButton";
            this.patronCancelButton.Size = new System.Drawing.Size(100, 28);
            this.patronCancelButton.TabIndex = 5;
            this.patronCancelButton.Text = "Cancel";
            this.patronCancelButton.UseVisualStyleBackColor = true;
            this.patronCancelButton.Click += new System.EventHandler(this.patronCancelButton_Click);
            this.patronCancelButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.patronCancelButton_MouseDown);
            // 
            // nameErrorProvider
            // 
            this.nameErrorProvider.ContainerControl = this;
            // 
            // idErrorProvider
            // 
            this.idErrorProvider.ContainerControl = this;
            // 
            // InsertPatronForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 230);
            this.Controls.Add(this.patronCancelButton);
            this.Controls.Add(this.patronOkButton);
            this.Controls.Add(this.patronIdLabel);
            this.Controls.Add(this.patronNameLabel);
            this.Controls.Add(this.patronIDInputBox);
            this.Controls.Add(this.patronNameInputBox);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "InsertPatronForm";
            this.Text = "Add New Patron";
            ((System.ComponentModel.ISupportInitialize)(this.nameErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.idErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label patronNameLabel;
        private System.Windows.Forms.Label patronIdLabel;
        private System.Windows.Forms.Button patronOkButton;
        private System.Windows.Forms.Button patronCancelButton;
        private System.Windows.Forms.ErrorProvider nameErrorProvider;
        private System.Windows.Forms.ErrorProvider idErrorProvider;
        public System.Windows.Forms.TextBox patronNameInputBox;
        public System.Windows.Forms.TextBox patronIDInputBox;
    }
}