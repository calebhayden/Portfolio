﻿namespace Lab_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.outputDisplay = new System.Windows.Forms.ListBox();
            this.buttonBox = new System.Windows.Forms.GroupBox();
            this.dowhileLoopButton = new System.Windows.Forms.RadioButton();
            this.forLoopButton = new System.Windows.Forms.RadioButton();
            this.whileLoopButton = new System.Windows.Forms.RadioButton();
            this.minInputBox = new System.Windows.Forms.TextBox();
            this.maxInputBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.runButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.buttonBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // outputDisplay
            // 
            this.outputDisplay.FormattingEnabled = true;
            this.outputDisplay.Location = new System.Drawing.Point(160, 3);
            this.outputDisplay.Name = "outputDisplay";
            this.outputDisplay.Size = new System.Drawing.Size(120, 264);
            this.outputDisplay.TabIndex = 7;
            // 
            // buttonBox
            // 
            this.buttonBox.Controls.Add(this.dowhileLoopButton);
            this.buttonBox.Controls.Add(this.forLoopButton);
            this.buttonBox.Controls.Add(this.whileLoopButton);
            this.buttonBox.Location = new System.Drawing.Point(12, 111);
            this.buttonBox.Name = "buttonBox";
            this.buttonBox.Size = new System.Drawing.Size(100, 98);
            this.buttonBox.TabIndex = 1;
            this.buttonBox.TabStop = false;
            this.buttonBox.Text = "Loop Using:";
            // 
            // dowhileLoopButton
            // 
            this.dowhileLoopButton.AutoSize = true;
            this.dowhileLoopButton.Location = new System.Drawing.Point(6, 65);
            this.dowhileLoopButton.Name = "dowhileLoopButton";
            this.dowhileLoopButton.Size = new System.Drawing.Size(69, 17);
            this.dowhileLoopButton.TabIndex = 4;
            this.dowhileLoopButton.Text = "Do-While";
            this.dowhileLoopButton.UseVisualStyleBackColor = true;
            // 
            // forLoopButton
            // 
            this.forLoopButton.AutoSize = true;
            this.forLoopButton.Location = new System.Drawing.Point(6, 42);
            this.forLoopButton.Name = "forLoopButton";
            this.forLoopButton.Size = new System.Drawing.Size(40, 17);
            this.forLoopButton.TabIndex = 3;
            this.forLoopButton.Text = "For";
            this.forLoopButton.UseVisualStyleBackColor = true;
            // 
            // whileLoopButton
            // 
            this.whileLoopButton.AutoSize = true;
            this.whileLoopButton.Checked = true;
            this.whileLoopButton.Location = new System.Drawing.Point(6, 19);
            this.whileLoopButton.Name = "whileLoopButton";
            this.whileLoopButton.Size = new System.Drawing.Size(52, 17);
            this.whileLoopButton.TabIndex = 2;
            this.whileLoopButton.TabStop = true;
            this.whileLoopButton.Text = "While";
            this.whileLoopButton.UseVisualStyleBackColor = true;
            // 
            // minInputBox
            // 
            this.minInputBox.Location = new System.Drawing.Point(12, 33);
            this.minInputBox.Name = "minInputBox";
            this.minInputBox.Size = new System.Drawing.Size(100, 20);
            this.minInputBox.TabIndex = 0;
            // 
            // maxInputBox
            // 
            this.maxInputBox.Location = new System.Drawing.Point(12, 76);
            this.maxInputBox.Name = "maxInputBox";
            this.maxInputBox.Size = new System.Drawing.Size(100, 20);
            this.maxInputBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "From:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "To:";
            // 
            // runButton
            // 
            this.runButton.Location = new System.Drawing.Point(12, 215);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(75, 23);
            this.runButton.TabIndex = 5;
            this.runButton.Text = "Run Loop";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(12, 244);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear List";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.maxInputBox);
            this.Controls.Add(this.minInputBox);
            this.Controls.Add(this.buttonBox);
            this.Controls.Add(this.outputDisplay);
            this.Name = "Form1";
            this.Text = "Lab 5";
            this.buttonBox.ResumeLayout(false);
            this.buttonBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox outputDisplay;
        private System.Windows.Forms.GroupBox buttonBox;
        private System.Windows.Forms.RadioButton dowhileLoopButton;
        private System.Windows.Forms.RadioButton forLoopButton;
        private System.Windows.Forms.RadioButton whileLoopButton;
        private System.Windows.Forms.TextBox minInputBox;
        private System.Windows.Forms.TextBox maxInputBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.Button clearButton;
    }
}

