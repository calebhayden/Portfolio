﻿//Grading ID B2732
//CIS 199-75, Lab 5, Due Sunday, Oct. 23rd, 2016
//This program uses nested ifs as well as three types of loops to display a sequence of numbers in a listbox. 


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int minNumber; //Variable to hold the first (smaller) input
        int maxNumber; //Variable to hold the second (larger) input 
        

        private void runButton_Click(object sender, EventArgs e)
        {
            //Attempts to parse both user inputs, if sucessful, it moves to the next step
            if (int.TryParse(minInputBox.Text, out minNumber))
            {
                if (int.TryParse(maxInputBox.Text, out maxNumber))
                {
                    //If the while loop button is checked, performs a while loop based on user input and displays it in the listbox
                    if (whileLoopButton.Checked)
                    {
                        while (minNumber <= maxNumber)
                        {
                            outputDisplay.Items.Add(minNumber);
                            minNumber++;
                        }
                    }
                    //If the while loop button is unchecked, checks if the for loop button is checked. If so, performs a for loop based on user input and displays 
                    //the results in the listbox 
                    else if (forLoopButton.Checked)
                    {
                        int count; //Variable used to hold input during the for loop
                        for (count = minNumber; count <= maxNumber; count++)
                        {
                            outputDisplay.Items.Add(count);
                        }
                    }
                    //If neither of the first two buttons are checked, assumes that the third is checked, performs a do-while loop based on user input
                    //and displays the results in the listbox
                    else
                        do
                        {
                            outputDisplay.Items.Add(minNumber);
                            minNumber++;
                        } while (minNumber <= maxNumber);
                }
                //If the second input cannot be parsed, displays an error message.
                else
                    MessageBox.Show("Please enter valid data in the second box.");
            }
            //If the first input cannot be parsed, displays an error message.
            else
                MessageBox.Show("Please enter valid data in the first box.");
        }



        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the output in the listbox. 
            outputDisplay.Items.Clear();
        }
    }
}

  

